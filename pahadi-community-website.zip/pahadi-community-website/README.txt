PAHADI COMMUNITY WEBSITE

Files:
- index.html: website structure and content
- style.css: visual design and responsive layout
- script.js: interactive district explorer and mobile navigation

HOW TO USE:
1. Extract this ZIP.
2. In VS Code choose File > Open Folder and select the extracted folder.
3. Open index.html to edit page content.
4. Open style.css to edit colours, spacing and layout.
5. Open script.js to edit district interactions and navigation.

BEFORE PUBLISHING:
In index.html, find the Discord button near the "Door is open" section:
  href="https://discord.com/"
Replace https://discord.com/ with your real Discord server invite URL.

PUBLISH TO GITHUB PAGES:
Copy the three website files into your existing pahadi-community repository.
Commit and push the changes to the branch/folder configured in Settings > Pages.
Do not upload the ZIP itself as the website source.

NOTES:
- This is a fresh redesign, not a copy of the reference website.
- The district explorer is interactive, but it is a selector/list rather than an official geographic map.
- Community member counts and live server statistics are not fabricated or displayed.
