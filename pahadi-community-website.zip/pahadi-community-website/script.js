const districts = [
  {name:"Dehradun",division:"GARHWAL DIVISION",region:"GARHWAL",symbol:"🏞️",desc:"A lively valley city framed by the Shivalik hills and the Himalayas."},
  {name:"Haridwar",division:"GARHWAL DIVISION",region:"GARHWAL",symbol:"🪔",desc:"A sacred city on the Ganga, known for its ghats, traditions and spiritual energy."},
  {name:"Pauri Garhwal",division:"GARHWAL DIVISION",region:"GARHWAL",symbol:"🌲",desc:"Quiet mountain towns, pine forests and sweeping Himalayan views."},
  {name:"Tehri Garhwal",division:"GARHWAL DIVISION",region:"GARHWAL",symbol:"🏞️",desc:"A region of mountain villages, river valleys and the striking Tehri lake."},
  {name:"Uttarkashi",division:"GARHWAL DIVISION",region:"GARHWAL",symbol:"🏔️",desc:"High Himalayan landscapes and gateways to revered mountain trails."},
  {name:"Chamoli",division:"GARHWAL DIVISION",region:"GARHWAL",symbol:"❄️",desc:"Home to dramatic peaks, alpine meadows and rich mountain heritage."},
  {name:"Rudraprayag",division:"GARHWAL DIVISION",region:"GARHWAL",symbol:"🌄",desc:"A beautiful meeting place of rivers, valleys and pilgrimage routes."},
  {name:"Almora",division:"KUMAON DIVISION",region:"KUMAON",symbol:"🌅",desc:"A historic hill town known for its culture, old bazaars and mountain views."},
  {name:"Nainital",division:"KUMAON DIVISION",region:"KUMAON",symbol:"🌊",desc:"Lake country, forested hills and lively hill-town heritage."},
  {name:"Pithoragarh",division:"KUMAON DIVISION",region:"KUMAON",symbol:"⛰️",desc:"A Himalayan frontier district with beautiful valleys and towering peaks."},
  {name:"Bageshwar",division:"KUMAON DIVISION",region:"KUMAON",symbol:"🛕",desc:"A confluence town surrounded by mountain villages and Kumaoni traditions."},
  {name:"Champawat",division:"KUMAON DIVISION",region:"KUMAON",symbol:"🌿",desc:"A historic region with forested slopes, temples and quiet landscapes."},
  {name:"Udham Singh Nagar",division:"KUMAON DIVISION",region:"KUMAON",symbol:"🌾",desc:"A diverse Terai district connecting plains, foothills and many communities."}
];
const list = document.getElementById("districtList");
const nameEl = document.getElementById("districtName");
const descEl = document.getElementById("districtDescription");
const divisionEl = document.getElementById("districtDivision");
const regionEl = document.getElementById("districtRegion");
const numberEl = document.getElementById("districtNumber");
const symbolEl = document.getElementById("districtSymbol");
districts.forEach((district,index)=>{
  const button=document.createElement("button");
  button.className="district-choice"+(index===0?" selected":"");
  button.type="button";
  button.innerHTML=`<span>${String(index+1).padStart(2,"0")}</span>${district.name}`;
  button.addEventListener("click",()=>{
    document.querySelectorAll(".district-choice").forEach(el=>el.classList.remove("selected"));
    button.classList.add("selected");
    nameEl.textContent=district.name;
    descEl.textContent=district.desc;
    divisionEl.textContent=district.division;
    regionEl.textContent=district.region;
    numberEl.textContent=`${String(index+1).padStart(2,"0")} / 13`;
    symbolEl.textContent=district.symbol;
  });
  list.appendChild(button);
});
const menuToggle=document.getElementById("menuToggle");
const nav=document.getElementById("mainNav");
menuToggle.addEventListener("click",()=>{
  const open=nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded",String(open));
});
nav.querySelectorAll("a").forEach(link=>link.addEventListener("click",()=>{
  nav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded","false");
}));
document.getElementById("year").textContent=new Date().getFullYear();
